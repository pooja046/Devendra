package com.ps.DTO;

public class BannerDTO {
	private String banner_image = "";
	private String banner_link = "";

	public String getBanner_image() {
		return banner_image;
	}

	public void setBanner_image(String banner_image) {
		this.banner_image = banner_image;
	}

	public String getBanner_link() {
		return banner_link;
	}

	public void setBanner_link(String banner_link) {
		this.banner_link = banner_link;
	}

}
