package com.ps.DTO;

public class SliderDTO {
	private String slider_image = "";
	private String image_link = "";
	private String Product_id = "";
	
	

	public String getProduct_id() {
		return Product_id;
	}

	public void setProduct_id(String product_id) {
		Product_id = product_id;
	}

	public String getImage_link() {
		return image_link;
	}

	public void setImage_link(String image_link) {
		this.image_link = image_link;
	}

	public String getSlider_image() {
		return slider_image;
	}

	public void setSlider_image(String slider_image) {
		this.slider_image = slider_image;
	}
	
	
}
