package com.ps.DTO;

public class ColorDTO {
private String vColorName="";
public String getvColorName() {
	return vColorName;
}
public void setvColorName(String vColorName) {
	this.vColorName = vColorName;
}
public String getvColorCode() {
	return vColorCode;
}
public void setvColorCode(String vColorCode) {
	this.vColorCode = vColorCode;
}
private String vColorCode="";
}
