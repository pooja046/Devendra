package com.ealpha.support;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ealpha.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

public class NotificationAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<NotificationDTO> notificationDTOs;
    private NotificationDTO notificationDTO;
    private DisplayImageOptions options;

    public NotificationAdapter(Context context,
                               ArrayList<NotificationDTO> notificationDTOs) {
        this.context = context;
        this.notificationDTOs = notificationDTOs;
        options = new DisplayImageOptions.Builder()
                .showImageOnLoading(R.drawable.ic_launcher)
                .showImageForEmptyUri(R.drawable.ic_launcher)
                .showImageOnFail(R.drawable.ic_launcher).cacheInMemory(true)
                .cacheOnDisk(true).considerExifParams(true)
                .bitmapConfig(Bitmap.Config.RGB_565).build();
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return notificationDTOs.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return notificationDTOs.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null) {
            convertView = ((LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                    .inflate(R.layout.notification_row, null);
            viewHolder = new ViewHolder();
            viewHolder.title = (TextView) convertView.findViewById(R.id.title);
            viewHolder.type = (TextView) convertView.findViewById(R.id.type);
            viewHolder.short_decs = (TextView) convertView.findViewById(R.id.short_decs);
            viewHolder.description = (TextView) convertView.findViewById(R.id.description);
            viewHolder.time = (TextView) convertView.findViewById(R.id.time);
            viewHolder.product_image = (ImageView) convertView.findViewById(R.id.product_image);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        notificationDTO = notificationDTOs.get(position);
        viewHolder.title.setText(notificationDTO.getTitle());
        viewHolder.type.setText(notificationDTO.getType());
        viewHolder.short_decs.setText(notificationDTO.getShort_dec());
        viewHolder.description.setText(notificationDTO.getDescription());
        viewHolder.time.setText(notificationDTO.getStart_at());
        try {
            if (notificationDTO.getImage().equals("http://ealpha.com/upload/mobile_notification/") || notificationDTO.getImage().trim().length() == 0) {
                viewHolder.product_image.setImageResource(R.drawable.cash_on_delivery);
            } else {
                ImageLoader.getInstance().displayImage(notificationDTO.getImage(),
                        viewHolder.product_image, options);
            }
        } catch (Exception e) {

        }
        return convertView;
    }

    private static class ViewHolder {
        private TextView title, type, short_decs, description, time;
        private LinearLayout main_view;
        private ImageView product_image;
    }
}
